// Substitua pelos dados do seu Firebase
export const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SUA_APP.firebaseapp.com",
  projectId: "SUA_PROJECT_ID",
  storageBucket: "SUA_PROJECT_ID.appspot.com",
  messagingSenderId: "SUA_SENDER_ID",
  appId: "SUA_APP_ID"
};
