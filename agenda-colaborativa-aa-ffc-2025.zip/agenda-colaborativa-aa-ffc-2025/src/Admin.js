import React from "react";

export default function Admin() {
  const handleCompartilhar = () => {
    const texto = encodeURIComponent("📄 Relatório do Evento - Confirmados: 18, Ausentes: 7");
    window.open(`https://api.whatsapp.com/send?text=${texto}`, "_blank");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Painel Administrativo</h2>
      <button onClick={handleCompartilhar}>📄 Partilhar Relatório no WhatsApp</button>
    </div>
  );
}
