# Agenda Colaborativa AA FFC 2025

## Como rodar localmente
1. Instale Node.js (https://nodejs.org).
2. Na pasta do projeto:
3. O app abre em `http://localhost:3000`.

## Como publicar online (grátis)
1. Crie conta no [Vercel](https://vercel.com).
2. Clique em "Novo Projeto".
3. Envie a pasta `agenda-colaborativa-aa-ffc-2025`.
4. Aguarde o deploy → link pronto ex:  

## Login Admin
- Email: marcojourdan@gmail.com  
- Senha: aedbdt25
