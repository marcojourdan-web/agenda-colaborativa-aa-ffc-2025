import React, { useState } from "react";

export default function Events() {
  const [confirmado, setConfirmado] = useState(false);

  return (
    <div style={{ padding: 20 }}>
      <h2>Eventos</h2>
      <div style={{ border: "1px solid #7A1F3D", padding: 10, margin: 10 }}>
        <h3>Caminhada na Sede FFC</h3>
        <p>Data: 20/10/2025 - 15h</p>
        <p>Local: Sede das Laranjeiras</p>
        <label>
          <input
            type="checkbox"
            checked={confirmado}
            onChange={(e) => setConfirmado(e.target.checked)}
          />
          Confirmo presença
        </label>
      </div>
    </div>
  );
}
